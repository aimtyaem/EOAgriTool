# Initialize Git
git init

# Add files
git add .

# Initial commit
git commit -m "Initial commit"

# Create new repository on GitHub (via website)
# Then link and push
git remote add origin https://github.com/aimtyaem/EOAgriTool
git branch -M main
git push -u origin main